This item has been downloaded from - https://karthiksrinivas.in/


LICENSE:
Use for Free, but please Set a Link


RIGHTS

You have rights for royalty free use for any or all of your personal and commercial projects.

You may modify the resources according to your requirements and use them royalty free in any or all of your personal or commercial projects. For example, you may include this resource on a website you will be designing for a client.

You are required to attribute or link to https://karthiksrinivas.in/ in any of projects.

karthiksrinivas.in will not be responsible for any outcome that may occur during the use of our resources.

We reserve the rights to change prices, conditions and revise the resources usage policy at any moment.


PROHIBITIONS
You do not have the rights to redistribute, resell, lease, license, sub-license or offer the file downloaded to any third party.

For any resalable web applications, software programs, web templates, app templates, merchandise etc. you should not include our graphics resources. This will be considered as a redistribution of our resources which is forbidden by us.


In case of any questions, you can reach out to aathis18@gmail.com